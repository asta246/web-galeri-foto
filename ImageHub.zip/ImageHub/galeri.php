<?php
    error_reporting(0);
    include 'db.php';
    $kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
    $a = mysqli_fetch_object($kontak);
    
    // Proses upload file gambar
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $image_name = $_FILES["image"]["name"];
        $image_tmp_name = $_FILES["image"]["tmp_name"];
        $image_path = "foto/" . $image_name;

        // Upload file gambar ke server
        if (move_uploaded_file($image_tmp_name, $image_path)) {
            // Simpan informasi foto ke database
            $query = "INSERT INTO tb_image (image_name, image, image_status, category_id, admin_name, date_created) 
                      VALUES ('$image_name', '$image_path', 1, '".$_POST['category_id']."', '".$_SESSION['a_global']->admin_name."', NOW())";
            mysqli_query($conn, $query);
        }
    }
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IMAGEHUB</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Global Styles */
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #fff; /* Mengubah latar belakang halaman menjadi putih */
            font-size: 16px;
            line-height: 1.6;
            color: #34495e;
            padding-top: 80px;
        }

        header {
            background: #7b1abc; /* Ubah ini jika ingin header berwarna lain */
            color: #fff;
            padding: 20px 0;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 100;
        }

        /* Header Styling */
        header h1 {
            font-size: 30px;
            padding-left: 20px;
            font-weight: 700;
            display: inline-block;
            color: #fff; /* Mengubah warna teks menjadi putih */
        }
        header h1 a {
            color: #fff !important; /* Mengubah warna teks menjadi putih */
            text-decoration: none; /* Menghapus garis bawah */
        }

        header ul {
            float: right;
            list-style: none;
            margin-right: 20px;
        }

        header ul li {
            display: inline-block;
        }

        header ul li a {
            padding: 14px 20px;
            display: inline-block;
            color: #fff;
            font-size: 16px;
            font-weight: 500;
            transition: background-color 0.3s;
            border-radius: 4px;
        }

        header ul li a:hover {
            background-color: rgb(123, 26, 188);
        }

        /* Search Section Styling */
        .search {
            padding: 50px 0 20px;
            background-color: #ecf0f1;
            text-align: center;
        }

        .search input[type="text"] {
            padding: 12px;
            width: 300px;
            border: 2px solid rgb(123, 26, 188);
            border-radius: 5px;
            margin-right: 10px;
            font-size: 16px;
        }

        .search input[type="submit"] {
            padding: 12px 20px;
            background-color: rgb(123, 26, 188);
            border: none;
            color: #fff;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .search input[type="submit"]:hover {
            background-color: rgb(123, 26, 188);
        }

        /* Gallery Section */
        .section {
            padding: 50px 0 50px; /* Menyesuaikan padding untuk konten */
        }

        .container {
            width: 85%;
            margin: 0 auto;
        }

        h3 {
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: 600;
            color: #34495e;
        }

        .box {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 30px;
        }

        .col-4 {
            background-color: #fff;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            overflow: hidden;
            transition: transform 0.3s;
        }

        .col-4:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .col-4 img {
            width: 100%;
            height: auto;
            border-radius: 5px;
            transition: transform 0.3s;
        }

        .col-4 img:hover {
            transform: scale(1.1);
        }

        .col-4 p {
            margin: 10px 0;
            font-size: 16px;
            color: #34495e;
        }

        .col-4 .nama {
            font-weight: 600;
        }

        .col-4 .harga {
            color: #7f8c8d;
        }

        /* Footer Styling */
        footer {
            background-color: #34495e;
            color: #fff;
            text-align: center;
            padding: 5px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        

        footer small {
            font-size: 14px;
        } 

        /* Responsive Design */
        @media screen and (max-width: 1024px) {
            .box {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media screen and (max-width: 768px) {
            header h1 {
                font-size: 24px;
            }

            header ul li a {
                font-size: 14px;
            }

            .box {
                grid-template-columns: repeat(2, 1fr);
            }

            .col-4 img {
                height: 200px;
            }
        }

        @media screen and (max-width: 480px) {
            header h1 {
                font-size: 20px;
            }

            header ul li a {
                font-size: 12px;
                padding: 8px 15px;
            }

            .box {
                grid-template-columns: 1fr;
            }

            .col-4 img {
                height: 150px;
            }
        }
    </style>
</head>

<body>
    <!-- header -->
    <header>
        <div class="container">
            <h1><a href="index.php">IMAGEHUB</a></h1>
            <ul>
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="registrasi.php">Registrasi</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </header>
    
    <!-- search -->
    <div class="search">
        <div class="container">
            <form action="galeri.php">
                <input type="text" name="search" placeholder="Cari Foto" value="<?php echo $_GET['search'] ?>" />
                <input type="hidden" name="kat" value="<?php echo $_GET['kat'] ?>" />
                <input type="submit" name="cari" value="Cari Foto" />
            </form>
        </div>
    </div>

    <div class="table-responsive">
    <?php
        // Query untuk mengambil data gambar dan kategori
        if ($_GET['search'] != '' || $_GET['kat'] != '') {
            $where = "AND tb_image.image_name LIKE '%" . $_GET['search'] . "%' AND tb_image.category_id LIKE '%" . $_GET['kat'] . "%' ";
        } else {
            $where = "";
        }

        $query = "SELECT tb_image.*, tb_category.category_name 
                  FROM tb_image 
                  JOIN tb_category ON tb_image.category_id = tb_category.category_id 
                  WHERE tb_image.image_status = 1 $where 
                  ORDER BY tb_category.category_name, tb_image.image_id DESC";

        $result = mysqli_query($conn, $query);

        // Cek apakah ada hasil
        if (mysqli_num_rows($result) > 0) {
            $current_category = null; // Untuk menyimpan kategori saat ini
            while ($row = mysqli_fetch_assoc($result)) {
                // Jika kategori baru ditemukan, tampilkan header kategori
                if ($current_category !== $row['category_name']) {
                    $current_category = $row['category_name'];
                    echo "<h3 style='text-align: left; margin-top: 30px;'>" . htmlspecialchars($current_category) . "</h3>";
                    echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%; text-align: center;'>
                            <thead>
                                <tr>
                                    <th>Gambar</th>
                                    <th>Nama Foto</th>
                                    <th>Admin</th>
                                    <th>Tanggal Upload</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>";
                }

                // Tampilkan baris data gambar
                echo "<tr>
                        <td><img src='foto/" . htmlspecialchars($row['image']) . "' style='width: 100px; height: auto;'></td>
                        <td>" . htmlspecialchars($row['image_name']) . "</td>
                        <td>" . htmlspecialchars($row['admin_name']) . "</td>
                        <td>" . htmlspecialchars($row['date_created']) . "</td>
                        <td><a href='detail-image.php?id=" . htmlspecialchars($row['image_id']) . "'>Detail</a></td>
                      </tr>";
            }
            // Tutup tabel setelah loop selesai
            echo "</tbody></table>";
        } else {
            echo "<p style='text-align: center;'>Foto tidak ada</p>";
        }
    ?>
</div>


    
    <!-- footer -->
    <footer>
        <div class="container">
            <small>Asta &copy; 2025 - ImageHub.</small>
        </div>
    </footer>
</body>
</html>
