<?php
	include 'db.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IMAGEHUB</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f7fc;
        margin: 0;
        padding: 0;
    }

    header {
        background-color:rgb(123, 26, 188);
        color: white;
        padding: 20px 0;
        text-align: center;
    }

    header h1 {
        margin: 0;
        font-size: 30px;
    }

    header ul {
        list-style: none;
        padding: 0;
        margin: 10px 0;
    }

    header ul li {
        display: inline;
        margin: 0 15px;
    }

    header ul li a {
        color: #fff;
        text-decoration: none;
    }

    header ul li a:hover {
        text-decoration: underline;
    }

    .container {
        width: 80%;
        max-width: 1200px;
        margin: 0 auto;
    }

    .section {
        margin-top: 40px;
    }

    .box {
        background-color: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 40px;
    }

    h3 {
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
    }

    input[type="text"], input[type="email"], input[type="password"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type="submit"] {
        background-color:rgb(26, 188, 50);
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 50%;
    }

    input[type="submit"]:hover {
        background-color:rgb(76, 8, 97);
    }

    footer {
        background-color: #343a40;
        color: white;
        text-align: center;
        padding: 10px;
        position: fixed;
        bottom: 0;
        width: 100%;
    }

    footer small {
        font-size: 12px;
    }

    @media (max-width: 768px) {
        .container {
            width: 90%;
        }
    }
</style>
</head>

<body>
    <!-- header -->
    <header>
        <div class="container">
        <h1><a href="index.php">IMAGEHUB</a></h1>
        <ul>
           <li><a href="galeri.php">Galeri</a></li>
           <li><a href="registrasi.php">Registrasi</a></li>
           <li><a href="login.php">Login</a></li>
        </ul>
        </div>
    </header>
    
    <!-- content -->
    <div class="section">
        <div class="container">
            <h3>Registrasi Akun</h3>
            <div class="box">
               <form action="" method="POST">
               <label for="nama">Nama user</label>
                   <input type="text" name="nama" placeholder="Nama User" class="input-control" required>
                   <label for="nama">Username</label>
                   <input type="text" name="user" placeholder="Username" class="input-control" required>
                   <label for="nama">Password</label>
                   <input type="text" name="pass" placeholder="Password" class="input-control" required>
                   <label for="nama">Nomor Telpon</label>
                   <input type="text" name="tlp" placeholder="Nomor Telpon" class="input-control" required>
                   <label for="nama">E-mail</label>
                   <input type="text" name="email" placeholder="E-mail" class="input-control" required>
                   <label for="nama">Alamat</label>
                   <input type="text" name="almt" placeholder="Alamat" class="input-control" required>
                   <input type="submit" name="submit" value="Submit" class="btn">
               </form>
               <?php
                   if(isset($_POST['submit'])){
					   
					   $nama = ucwords($_POST['nama']);
					   $username = $_POST['user'];
					   $password = $_POST['pass'];
					   $telpon = $_POST['tlp'];
					   $mail = $_POST['email'];
					   $alamat = ucwords($_POST['almt']);
					   
					   $insert = mysqli_query($conn, "INSERT INTO tb_admin VALUES (
					                        null,
											'".$nama."',
											'".$username."',
											'".$password."',
											'".$telpon."',
											'".$mail."',
											'".$alamat."')
											
											");
						if($insert){
							echo '<script>alert("Registrasi berhasil")</script>';
							echo '<script>window.location="login.php"</script>';
						}else{
						    echo 'gagal '.mysqli_error($conn);
						}
						
					   }
			   ?>
            </div>
            
            </div>
        </div>
        </div>
    </div>
    
    <!-- footer -->
    <footer>
        <div class="container">
            <small>Asta &copy; 2025 - ImageHub.</small>
        </div>
    </footer>
</body>
</html>