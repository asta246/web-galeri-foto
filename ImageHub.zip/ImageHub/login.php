<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IMAGEHUB</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background:rgb(219, 153, 234);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('img/background.jpg');
            background-size: cover; 
            background-position: center;
            background-attachment: fixed;
        }

        #bg-login {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .box-login {
            background: rgba(255, 255, 255, 0.8);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            border-radius: 8px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .box-login h2 {
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
            color:rgb(123, 26, 188);
        }

        .input-control {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            outline: none;
            font-size: 16px;
            transition: border-color 0.3s;
        }

        .input-control:focus {
            border-color:rgb(123, 26, 188);
        }

        .btn {
            width: 100%;
            padding: 12px;
            background-color:rgb(123, 26, 188);
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color:rgb(123, 26, 188);
        }

        p {
            margin-top: 20px;
            font-size: 14px;
        }

        p a {
            color: rgb(123, 26, 188);
            text-decoration: none;
            font-weight: 500;
        }

        p a:hover {
            text-decoration: underline;
        }

        /* Responsive Design */
        @media screen and (max-width: 768px) {
            .box-login {
                width: 90%;
                padding: 30px;
            }
        }
    </style>
</head>

<body id="bg-login">
    <div class="box-login">
        <h2>Login</h2>
        <form action="" method="POST">
            <input type="text" name="user" placeholder="Username" class="input-control" required>
            <input type="password" name="pass" placeholder="Password" class="input-control" required>
            <input type="submit" name="submit" value="Login" class="btn">
        </form>
        <?php
            if(isset($_POST['submit'])){
                session_start();
                include 'db.php';

                $user = mysqli_real_escape_string($conn, $_POST['user']);
                $pass = mysqli_real_escape_string($conn, $_POST['pass']);
                
                $cek = mysqli_query($conn, "SELECT * FROM tb_admin WHERE username = '".$user."' AND password = '".$pass."'");
                if(mysqli_num_rows($cek) > 0){
                    $d = mysqli_fetch_object($cek);
                    $_SESSION['status_login'] = true;
                    $_SESSION['a_global'] = $d;
                    $_SESSION['id'] = $d->admin_id;
                    echo '<script>window.location="dashboard.php"</script>';
                }else{
                    echo '<script>alert("Username atau password anda salah")</script>';
                }
            }
        ?>
        <p>Belum punya akun? daftar <a href="registrasi.php">DISINI</a></p>
        <p>atau klik <a href="index.php">Kembali</a></p>
    </div>
</body>
</html>
