<?php
    session_start();
    include 'db.php';
    if ($_SESSION['status_login'] != true) {
        echo '<script>window.location="login.php"</script>';
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IMAGEHUB</title>
<!-- Link ke file CSS -->
<style>
@charset "utf-8";
/* CSS Document */
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-family: 'Quicksand', sans-serif;
}
body {
    background-color: #f4f7fa;
    font-size: 16px;
    line-height: 1.6;
}

/* Header Styling */
header {
    background-color: rgb(123, 26, 188);
    color: #fff;
    padding: 3px 0; /* Lebih kecil padding navbar */
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 100;
}

header h1 {
    float: left;
    padding-left: 10px;
    font-size: 35px; /* Ukuran font lebih kecil untuk header */
    line-height: 20px; /* Mengatur tinggi baris agar teks sedikit ke atas */
}

header h1 a {
    color: #fff !important; /* Mengubah warna teks menjadi putih */
    text-decoration: none; /* Menghapus garis bawah */
}

header ul {
    float: right;
    list-style: none;
    margin-right: 10px;
}

header ul li {
    display: inline-block;
}

header ul li a {
    padding: 6px 10px; /* Lebih kecil padding item navbar */
    display: inline-block;
    color: #fff;
    font-size: 18px; /* Ukuran font lebih kecil pada navbar item */
    transition: background-color 0.3s;
}

header ul li a:hover {
    background-color: rgb(76, 8, 97);
}


/* Container */
.container {
    width: 80%;
    margin: 0 auto;
    padding-top: 60px; /* Space for fixed header */
    padding-bottom: 60px; /* Tambahkan ruang bawah agar footer tidak menutupi konten */
}

/* Dashboard Section */
.section {
    padding: 40px 0;
}

/* Box Styling */
.box {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px; /* Lebih kecil padding box */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
    margin-top: 50px; /* Menambahkan jarak antara navbar dan box */
}


.box h3 {
    font-size: 20px; /* Ukuran font lebih kecil untuk judul box */
    font-weight: 600;
    color: #34495e;
    margin-bottom: 10px;
}

.box p {
    margin-bottom: 10px;
}

/* Table Styling */
.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

.table th,
.table td {
    padding: 8px 10px; /* Lebih kecil padding tabel */
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.table th {
    background-color: rgb(123, 26, 188);
    color: #fff;
}

.table td {
    background-color: #fff;
    color: #34495e;
}

.table tr:hover {
    background-color: #f1f1f1;
}

.table img {
    border-radius: 5px;
}

/* Agar tombol Edit dan Hapus sejajar */
.table td .btn-container {
    display: flex;
    gap: 8px; /* Jarak antar tombol */
    justify-content: flex-start; /* Penataan tombol di sebelah kiri */
}

.table a.btn {
    padding: 6px 12px; /* Lebih kecil padding tombol */
    background-color: rgb(123, 26, 188);
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    font-weight: bold;
    transition: background-color 0.3s;
}

.table a.btn:hover {
    background-color: rgb(76, 8, 97);
}

/* Footer Styling */
footer {
    background-color: rgb(123, 26, 188);
    color: #fff;
    text-align: center;
    padding: 6px; /* Mengurangi padding footer */
    position: relative; /* Mengubah posisi footer menjadi relative */
    width: 100%;
    bottom: 0;
    margin-top: 8px; /* Mengurangi jarak antara footer dan konten lebih kecil */
}

footer small {
    font-size: 12px; /* Ukuran font lebih kecil pada footer */
}


/* Responsive Design */
@media screen and (max-width: 768px) {
    .container {
        width: 90%;
    }

    header h1 {
        font-size: 22px; /* Ukuran font tetap kecil */
    }

    header ul li a {
        font-size: 12px; /* Ukuran font lebih kecil pada navbar item */
    }

    .table th,
    .table td {
        padding: 6px 8px; /* Lebih kecil padding tabel */
    }

    footer small {
        font-size: 10px; /* Ukuran font lebih kecil pada footer */
    }
}
</style>
</head>

<body>
    <!-- header -->
    <header>
        <div class="container">
        <h1><a href="dashboard.php">IMAGEHUB</a></h1>
        <ul>
           <li><a href="dashboard.php">Dashboard</a></li>
           <li><a href="profil.php">Profil</a></li>
           <li><a href="data-image.php">Data Foto</a></li>
           <li><a href="Keluar.php">Keluar</a></li>
        </ul>
        </div>
    </header>
        
    <!-- content -->
    <div class="section">
        <div class="container">
            <h3>Data Galeri Foto</h3>
            <div class="box">
                <p><a href="tambah-image.php" class="btn">Tambah Data</a></p><br>
                <table class="table">
                    <thead>
                        <tr>
                           <th width="60px">No</th>
                           <th>Kategori</th>
                           <th>Nama User</th>
                           <th>Nama Foto</th>
                           <th>Deskripsi</th>
                           <th>Gambar</th>
                           <th>Status</th>
                           <th width="150px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                            $user = $_SESSION['a_global']->admin_id;
                            $foto = mysqli_query($conn, "SELECT * FROM tb_image WHERE admin_id = '$user' ");
                            if (mysqli_num_rows($foto) > 0) {
                                while ($row = mysqli_fetch_array($foto)) {
                        ?>
                        <tr>
                           <td><?php echo $no++ ?></td>
                           <td><?php echo $row['category_name'] ?></td>
                           <td><?php echo $row['admin_name'] ?></td>
                           <td><?php echo $row['image_name'] ?></td>
                           <td><?php echo $row['image_description'] ?></td>
                           <td><a href="foto/<?php echo $row['image'] ?>" target="_blank"><img src="foto/<?php echo $row['image'] ?>" width="50px"></a></td>
                           <td><?php echo ($row['image_status'] == 0) ? 'Tidak Aktif' : 'Aktif'; ?></td>
                           <td>
                               <div class="btn-container">
                                  <a href="edit-image.php?id=<?php echo $row['image_id'] ?>" class="btn">Edit</a> 
                                  <a href="proses-hapus.php?idp=<?php echo $row['image_id'] ?>" onclick="return confirm('Yakin Ingin Hapus ?')" class="btn">Hapus</a>
                               </div>
                           </td>
                        </tr>
                        <?php }} else { ?>
                             <tr>
                                <td colspan="8">Tidak ada data</td>
                             </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- footer -->
    <footer>
        <div class="container">
            <small>Asta &copy; 2025 - ImageHub.</small>
        </div>
    </footer>
</body>
</html>
