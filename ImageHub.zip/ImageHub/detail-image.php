<?php
session_start();
error_reporting(0);
include 'db.php';

// Cek apakah ada query ID foto
$produk = mysqli_query($conn, "SELECT * FROM tb_image WHERE image_id = '".$_GET['id']."' ");
$p = mysqli_fetch_object($produk);

// Mengambil jumlah like pada foto
$like_count = mysqli_query($conn, "SELECT COUNT(*) AS total_likes FROM tb_likes WHERE image_id = '".$_GET['id']."' ");
$like_count_data = mysqli_fetch_object($like_count);
$total_likes = $like_count_data->total_likes;

// Menambahkan komentar
if (isset($_POST['submit_comment'])) {
    if (!isset($_SESSION['status_login'])) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        echo "<script>alert('Anda harus login terlebih dahulu!'); window.location='login.php';</script>";
    } else {
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);
        $user_id = $_SESSION['id']; // ID pengguna yang login
        $image_id = $_POST['image_id'];

        if (!empty($comment)) {
            // Menambahkan komentar
            $insert_query = $conn->prepare("INSERT INTO tb_comments (image_id, user_id, comment_text) VALUES (?, ?, ?)");
            $insert_query->bind_param("iis", $image_id, $user_id, $comment_text); // 'iis' berarti int, int, string

            if ($insert_query->execute()) {
                echo "<script>document.getElementById('comments-list').innerHTML += '<p><strong>".$_SESSION['username']."</strong>: ".$comment_text."';</script>";
            } else {
                echo "<script>alert('Terjadi kesalahan saat menambahkan komentar.');</script>";
            }
            $insert_query->close();
        } else {
            echo "<script>alert('Komentar tidak boleh kosong!');</script>";
        }
    }
}

// Mengambil komentar yang ada
$comments = mysqli_query($conn, "SELECT * FROM tb_comments LEFT JOIN tb_admin ON tb_comments.user_id = tb_admin.admin_id WHERE tb_comments.image_id = '" . $_GET['id'] . "' ORDER BY date_created DESC");

// Menambahkan Like
if (isset($_POST['like_submit'])) {
    if (!isset($_SESSION['status_login'])) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        echo "<script>alert('Anda harus login terlebih dahulu!'); window.location='login.php';</script>";
    } else {
        $user_id = $_SESSION['id']; // ID pengguna yang login
        $image_id = $_GET['id'];

        // Memeriksa apakah pengguna sudah memberikan like
        $check_like = mysqli_query($conn, "SELECT * FROM tb_likes WHERE image_id = '$image_id' AND user_id = '$user_id'");
        if (mysqli_num_rows($check_like) == 0) {
            // Menambahkan like ke database jika belum ada
            $insert_like = mysqli_query($conn, "INSERT INTO tb_likes (image_id, user_id) VALUES ('$image_id', '$user_id')");
            if ($insert_like) {
                echo "<script>alert('Like berhasil ditambahkan!'); window.location='".$_SERVER['REQUEST_URI']."';</script>";
            }
        } else {
            // Menghapus like jika sudah ada
            $delete_like = mysqli_query($conn, "DELETE FROM tb_likes WHERE image_id = '$image_id' AND user_id = '$user_id'");
            if ($delete_like) {
                echo "<script>alert('Like telah dibatalkan!'); window.location='".$_SERVER['REQUEST_URI']."';</script>";
            }
        }
        
    }
}
// Menghapus komentar
if (isset($_GET['delete_comment'])) {
    $comment_id = $_GET['delete_comment'];

    // Menggunakan prepared statement untuk mencegah SQL injection
    $delete_query = $conn->prepare("DELETE FROM tb_comments WHERE comment_id = ?");
    $delete_query->bind_param("i", $comment_id); // 'i' berarti integer

    if ($delete_query->execute()) {
        echo "<script>alert('Komentar berhasil dihapus!'); window.location='".$_SERVER['REQUEST_URI']."';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan saat menghapus komentar.');</script>";
    }

    $delete_query->close();
}

// Menampilkan komentar yang ada
$comments = mysqli_query($conn, "SELECT * FROM tb_comments WHERE image_id = '" . $_GET['id'] . "' ORDER BY date_created DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WEB Galeri Foto</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome -->
<style>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

/* CSS Styles */
* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    background-color: #f4f7fa;
    font-size: 16px;
    line-height: 1.6;
    color: #34495e;
}

/* Header Styling */
header {
    background-color: rgb(123, 26, 188);
    color: #fff;
    padding: 15px 0;
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 100;
}

header h1 {
    float: left;
    padding-left: 20px;
    font-size: 24px;
}

header h1 a {
    color: #fff !important;
    text-decoration: none;
}

header ul {
    float: right;
    list-style: none;
    margin-right: 20px;
}

header ul li {
    display: inline-block;
}

header ul li a {
    padding: 15px 20px;
    display: inline-block;
    color: #fff;
    font-size: 16px;
    transition: background-color 0.3s;
    text-decoration: none;

}

header ul li a:hover {
    background-color: rgb(76, 8, 97);
}

/* Product Detail Section */
.section {
    padding: 80px 0 50px 0;
}

.container {
    width: 80%;
    margin: 0 auto;
}

h3 {
    font-size: 26px;
    margin-bottom: 20px;
    font-weight: 600;
}

/* Mengatur ukuran box */
.box {
    display: flex;
    flex-wrap: nowrap;
    justify-content: space-between;
    gap: 20px;
    background-color: #fff;
    padding: 15px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    width: 1000px; /* Atur lebar tetap */
    height: 500px; /* Atur tinggi tetap */
    margin: 0 auto; /* Memastikan box berada di tengah */
}



/* Gambar di kiri */
.col-2-left {
    flex: 1;
    min-width: 300px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}

.col-2-left {
    width: 100%;
    min-height: 300px; /* Sesuaikan tinggi minimal */
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden; /* Mencegah gambar keluar */
    background-color: #f0f0f0; /* Biar kelihatan batasnya */
}


.col-2-left img {
    width: 100%;
    height: 100%; /* Pastikan gambar mengisi box */
    max-height: 300px; /* Atur max-height agar gambar tidak membesar melebihi batas */
    max-width: 100%;
    max-height: 100%;
    object-fit: contain; /* Pastikan gambar tetap proporsional */
    border-radius: 8px;
    overflow: hidden;
}



/* Detail produk di kanan */
.col-2-right {
    flex: 1.5;
    min-width: 300px;
}

.col-2-right h3 {
    font-size: 22px;
    font-weight: 600;
    color: #34495e;
}

.col-2-right p {
    font-size: 14px;
    line-height: 1.8;
    color: #34495e;
}

.col-2-left, .col-2-right {
    overflow: hidden;
}


/* Menambahkan styling untuk tombol like dan komentar */
.actions {
    display: flex;
    gap: 15px; /* Jarak antar tombol like dan komentar */
    margin-top: 15px;
}

.actions button {
    padding: 10px;
    border: none;
    background-color: rgb(123, 26, 188);
    color: #fff;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.actions button:hover {
    background-color: rgb(76, 8, 97);
}

.comment-section {
    margin-top: 15px;
    padding: 15px;
    background-color: #f8f9fa;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

#comments-list {
    max-height: 300px; /* Tentukan tinggi maksimum untuk area komentar */
    overflow-y: auto;  /* Aktifkan scroll vertikal */
    margin-top: 10px;
    padding-right: 10px;
}


#comment-text {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ddd;
}

.submit-comment-btn {
    background-color: rgb(123, 26, 188);
    color: white;
    border-radius: 5px;
    padding: 8px 12px;
    border: none;
    cursor: pointer;
}

.submit-comment-btn:hover {
    background-color: rgb(76, 8, 97);
}

/* Footer Styling */
footer {
    color: #fff;
    text-align: center;
    padding: 15px;
    position: fixed;
    bottom: 0;
    width: 100%;
}

footer small {
    font-size: 14px;
}

@media screen and (max-width: 768px) {
    .container {
        width: 90%;
    }

    footer small {
        font-size: 12px;
    }
}

.like-btn, .comment-btn {
    padding: 10px;
    border: none;
    background-color: rgb(123, 26, 188);
    color: #fff;
    border-radius: 5px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: background-color 0.3s;
}

.like-btn:hover, .comment-btn:hover {
    background-color: rgb(76, 8, 97);
}

.like-btn i, .comment-btn i {
    font-size: 18px; /* Ukuran ikon */
}
.gambar-container {
    width: 150px; /* Atur ukuran sesuai kebutuhan */
    height: 150px; 
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
}

.gambar-container img {
    max-width: 100%;
    max-height: 100%;
    object-fit: cover; /* Bisa pakai 'contain' kalau mau tetap terlihat seluruhnya */
}

</style>
</head>
</head>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#comment-form').on('submit', function(e) {
            e.preventDefault();
            let formData = $(this).serialize();
            $.ajax({
                url: 'add_comment.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    $('#comments-list').prepend(response); // Tambahkan komentar baru ke atas daftar
                    $('#comment-text').val(''); // Kosongkan kolom komentar
                },
                error: function() {
                    alert('Terjadi kesalahan. Coba lagi.');
                }
            });
        });
    });
</script>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <h1><a href="index.php">IMAGEHUB</a></h1>
            <ul>
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="registrasi.php">Registrasi</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </header>
    
     <!-- product detail -->
      
     <div class="section">
        <div class="container">
            <h3>Detail Foto</h3>
            <div class="box">
            <div class="col-2">
            <div class="gambar-container">
    <img src="foto/<?php echo $p->image ?>" id="image-1" class="clickable-image, enlarged, enlarged::before" width="100%" />
</div>

<style>
    /* Styling untuk gambar */
    .clickable-image {
        transition: transform 0.3s ease; /* animasi perbesaran */
        cursor: pointer;
        display: block;
        margin: 0 auto;
        max-width: 100%;
        width: 1000px; /* Atur lebar gambar */
    height: 100000px; /* Atur tinggi gambar */
    }

    /* Gaya ketika gambar diperbesar */
    .enlarged {
        transform: translate(-50%, -50%) scale(2); /* Perbesar gambar dengan faktor 1.5 */
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.4); /* Posisikan di tengah */
        z-index: 1000; /* Pastikan gambar berada di atas konten lainnya */
        max-width: 100px; /* Hilangkan pembatasan ukuran */
        max-height: 100px;
    }

    /* Membuat background gelap saat gambar diperbesar */
    .enlarged::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
        z-index: -1; /* Pastikan background di belakang gambar */
    }
</style>


            <div class="col-2">
                <h3><?php echo $p->image_name ?><br />Kategori : <?php echo $p->category_name ?></h3>
                <h4>Nama User : <?php echo $p->admin_name ?><br />
                Upload Pada Tanggal : <?php echo $p->date_created ?></h4>
                <p>Deskripsi :<br />
                    <?php echo $p->image_description ?>
                </p>

                <div class="actions">
                    <!-- Like Button -->
                    <form method="POST">
    <button type="submit" name="like_submit" class="like-btn">
        <i class="fas fa-thumbs-up"></i>
        <?php echo $total_likes; ?> Like(s)
                            
                        </button>
                    </form>

                    <!-- Komentar Button -->
                    <form method="POST">
                        <button type="button" id="comment-btn" class="comment-btn">
                            <i class="fas fa-comment-dots"></i> Komentar
                        </button>
                    </form>
                </div>

                <!-- Bagian untuk Formulir Komentar dan Daftar Komentar -->
                <div id="comment-section" class="comment-section" style="display:none;">
                    <h3>Komentar:</h3>
                    <form id="comment-form" method="POST">
                        <textarea name="comment_text" id="comment-text" rows="4" placeholder="Tulis komentar Anda..." required></textarea><br>
                        <button type="submit" name="comment_submit" class="submit-comment-btn">Kirim Komentar</button>
                    </form>

                    <div id="comments-list">
    <h5>Daftar Komentar:</h5>
    <div class="comments-container">
        <?php
            $comments = mysqli_query($conn, "SELECT * FROM tb_comments LEFT JOIN tb_admin ON tb_comments.user_id = tb_admin.admin_id WHERE tb_comments.image_id = '".$p->image_id."' ORDER BY tb_comments.date_created DESC");
            while ($comment = mysqli_fetch_array($comments)) {
                echo "<p><strong>".$comment['admin_name']."</strong>: ".$comment['comment']." ";
                if (isset($_SESSION['status_login']) && $_SESSION['id'] == 1) { // Admin dapat menghapus komentar
                    echo "<a href='?id=".$p->image_id."&delete_comment=".$comment['comment_id']."' onclick='return confirm(\"Apakah Anda yakin ingin menghapus komentar ini?\")'>[Hapus]</a>";
                }
                echo "</p>";
            }
        ?>
    </div>
</div>


    
    <!-- footer -->
    <footer>
        <div class="container">
            <small>Copyright &copy; 2024 - Web Galeri Foto.</small>
        </div>
    </footer>

    <script>
    document.getElementById('comment-btn').addEventListener('click', function() {
        // Menampilkan bagian komentar saat ikon diklik
        var commentSection = document.getElementById('comment-section');
        commentSection.style.display = (commentSection.style.display === 'none' || commentSection.style.display === '') ? 'block' : 'none';
    });

    document.getElementById('comment-form').addEventListener('submit', function(event) {
        event.preventDefault(); // Mencegah halaman di-reload

        var commentText = document.getElementById('comment-text').value;
        if (commentText.trim() !== '') {
            // Kirim komentar ke server menggunakan AJAX
            var formData = new FormData();
            formData.append('comment_text', commentText);
            formData.append('comment_submit', true);
            formData.append('image_id', '<?php echo $p->image_id; ?>');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', '', true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    // Tambahkan komentar yang baru ke daftar komentar
                    var newComment = document.createElement('p');
                    newComment.innerHTML = "<strong><?php echo $_SESSION['username']; ?></strong>: " + commentText;
                    document.getElementById('comments-list').appendChild(newComment);

                    // Kosongkan input textarea setelah mengirim
                    document.getElementById('comment-text').value = '';
                }
            };
            xhr.send(formData);
        }
    });

    document.querySelector("#image-1").addEventListener("click", function() {
    this.classList.toggle("enlarged");
});


    </script>
</body>
</html> 