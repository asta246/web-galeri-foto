<?php
    include 'db.php';
    $kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
    $a = mysqli_fetch_object($kontak);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IMAGEHUB</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f8fc;
            color: #333;
        }

        /* Header Section */
        header {
            background-color:rgb(123, 26, 188);
            color: white;
            padding: 20px 0;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 100;
        }

        header .container {
            width: 90%;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 a {
            font-size: 32px;
            color: white;
            text-decoration: none;
            font-weight: 600;
        }

        header nav ul {
            display: flex;
            list-style: none;
        }

        header nav ul li {
            margin-left: 20px;
        }

        header nav ul li a {
            color: white;
            font-size: 16px;
            font-weight: 500;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        header nav ul li a:hover {
            background-color:rgb(123, 26, 188);
        }

        /* Search Section */
        .search {
            margin-top: 100px;
            padding: 30px 0;
            background-color: #ecf0f1;
            text-align: center;
        }

        .search input[type="text"] {
            padding: 12px;
            width: 40%;
            border: 2px solid rgb(123, 26, 188);
            border-radius: 25px;
            font-size: 16px;
            outline: none;
            margin-right: 10px;
            transition: border-color 0.3s;
        }

        .search input[type="text"]:focus {
            border-color:rgb(123, 26, 188);
        }

        .search input[type="submit"] {
            padding: 12px 20px;
            background-color:rgb(123, 26, 188);
            color: #fff;
            font-size: 16px;
            border-radius: 25px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .search input[type="submit"]:hover {
            background-color:rgb(123, 26, 188);
        }

        /* Category Section */
/* Category Section */
.section {
    padding: 50px 0;
    background-color: #fff;
    text-align: center;
    border: 2px solid #ddd; /* Menambahkan border di sekitar kategori */
    border-radius: 10px; /* Membuat sudut kotak melengkung */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Bayangan halus di sekitar kategori */
    margin: 20px auto; /* Memberikan jarak dengan elemen di luar kategori */
    max-width: 1200px; /* Membatasi lebar maksimum kategori */
}

.section h3 {
    font-size: 28px;
    color: #34495e;
    margin-bottom: 30px;
    font-weight: 600;
}

/* Category Box Styling */
.box {
    display: flex;
    flex-wrap: wrap;
    gap: 20px; /* Menjauhkan ikon kategori */
    justify-content: center; /* Menyusun item di tengah secara horizontal */
}

.col-5 {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out, box-shadow 0.3s ease;
    text-align: center;
    border: 2px solid #ddd; /* Border di sekitar ikon kategori */
    width: 120px; /* Menetapkan lebar yang konsisten pada box kategori */
    overflow: hidden; /* Menjaga agar teks tidak keluar dari box */
    display: flex;
    flex-direction: column; /* Menyusun elemen di dalam box secara vertikal */
    align-items: center; /* Mengatur elemen di tengah */
    justify-content: space-between; /* Memberikan ruang yang cukup antar elemen */
}

.col-5:hover {
    transform: translateY(-10px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    border-color: rgb(123, 26, 188); /* Warna border berubah saat hover */
}

.col-5 img {
    width: 50px;
    margin-bottom: 10px;
}

.col-5 p {
    color: #34495e;
    font-size: 16px;
    font-weight: 500;
    white-space: normal; /* Agar teks bisa membungkus (wrap) jika panjang */
    word-wrap: break-word; /* Memastikan kata tidak keluar dari kotak */
    margin-top: 10px;
    text-align: center;
    line-height: 1.4; /* Menambahkan jarak antar baris untuk teks agar lebih nyaman dibaca */
}


        /* New Product Section */
        .new-product {
            padding: 50px 0;
            text-align: center;
        }

        .new-product h3 {
            font-size: 28px;
            color: #34495e;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .new-product .box {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .col-4 {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease;
        }

        .col-4:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .col-4 img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 5px;
            transition: transform 0.3s;
        }

        .col-4 img:hover {
            transform: scale(1.05);
        }

        .col-4 p {
            color: #34495e;
            font-size: 14px;
            text-align: center;
        }

        .col-4 .nama {
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
        }

        /* Footer Section */
        footer {
            background-color: rgb(123, 26, 188);
            color: white;
            text-align: center;
            padding: 20px;
        }

        footer small {
            font-size: 14px;
        }

        /* Responsive Design */
        @media screen and (max-width: 1024px) {
            .box {
                grid-template-columns: repeat(4, 1fr);
            }

            .new-product .box {
                grid-template-columns: repeat(3, 1fr);
            }

            .search input[type="text"] {
                width: 50%;
            }
        }

        @media screen and (max-width: 768px) {
            .box {
                grid-template-columns: repeat(3, 1fr);
            }

            .new-product .box {
                grid-template-columns: repeat(2, 1fr);
            }

            .search input[type="text"] {
                width: 60%;
            }
        }

        @media screen and (max-width: 480px) {
            header h1 {
                font-size: 24px;
            }

            header nav ul li a {
                font-size: 12px;
                padding: 8px 12px;
            }

            .box {
                grid-template-columns: 1fr;
            }

            .new-product .box {
                grid-template-columns: 1fr;
            }

            .col-4 img {
                height: 120px;
            }

            .search input[type="text"] {
                width: 80%;
            }
        }
    </style>
</head>

<body>
    <!-- Header Section -->
    <header>
        <div class="container">
            <h1><a href="dashboard.php">IMAGEHUB</a></h1>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
           <li><a href="profil.php">Profil</a></li>
           <li><a href="data-image.php">Data Foto</a></li>
           <li><a href="Keluar.php">Keluar</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Search Section -->
    <div class="search">
        <div class="container">
            <form action="galeri.php">
                <input type="text" name="search" placeholder="Cari Foto" />
                <input type="submit" name="cari" value="Cari Foto" />
            </form>
        </div>
    </div>

    <!-- New Photos Section -->
    <div class="new-product">
        <div class="container">
            <h3>Foto Terbaru</h3>
            <div class="box">
                <?php
                    $foto = mysqli_query($conn, "SELECT * FROM tb_image WHERE image_status = 1 ORDER BY image_id DESC LIMIT 8");
                    if(mysqli_num_rows($foto) > 0){
                        while($p = mysqli_fetch_array($foto)){
                ?>
                <a href="detail_imagedas.php?id=<?php echo $p['image_id'] ?>">
                    <div class="col-4">
                        <img src="foto/<?php echo $p['image'] ?>" />
                        <p class="nama"><?php echo substr($p['image_name'], 0, 30) ?></p>
                        <p class="admin">Nama User: <?php echo $p['admin_name'] ?></p>
                        <p><?php echo $p['date_created'] ?></p>
                    </div>
                </a>
                <?php }}else{ ?>
                    <p>Foto tidak ada</p>
                <?php } ?>
            </div>
        </div>
    </div>

    <!-- Footer Section -->
    <footer>
        <div class="container">
            <small>Asta &copy; 2025 - ImageHub.</small>
        </div>
    </footer>
</body>
</html>
