-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2025 at 08:34 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galerifoto`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE IF NOT EXISTS `tb_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_telp` varchar(20) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_address` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_address`) VALUES
(5, 'NoniAstara', 'asta', 'asta', '085223922758', 'amtskni@gmail.com', 'Baharutara'),
(6, 'Al', 'Al', '1111', '085223921358', 'al022@gmail.com', 'Baharutara'),
(7, 'Nadia', 'Nadia R.', '1234', '084568922758', 'nadia@gmail.com', 'Baharutara'),
(8, 'Stefani', 'Stefani L.', '2345', '085228469358', 'Stefanii@gmail.com', 'Bunut'),
(9, 'Stefani', 'stefani', '2345', '084578456812', 'stefani@gmail.com', 'Bunut'),
(10, 'Eka Purwati', 'eka', 'eka123', '082325091453', 'eka@gmail.com', 'Kecamatan Bahar Utara, Desa Talang Bukit Unit 6 Rt 09'),
(11, 'Devi Safira', 'devi', '4444', '084578454756', 'devi@gmail.com', 'Kecamatan Batang Hari, Ladang Pris');

-- --------------------------------------------------------

--
-- Table structure for table `tb_category`
--

CREATE TABLE IF NOT EXISTS `tb_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_category`
--

INSERT INTO `tb_category` (`category_id`, `category_name`) VALUES
(1, 'seni rupa'),
(2, 'olahraga'),
(3, 'makanan'),
(4, 'view'),
(5, 'anime');

-- --------------------------------------------------------

--
-- Table structure for table `tb_comments`
--

CREATE TABLE IF NOT EXISTS `tb_comments` (
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nama_pengguna` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_image`
--

CREATE TABLE IF NOT EXISTS `tb_image` (
  `image_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `image_description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `image_status` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_image`
--

INSERT INTO `tb_image` (`image_id`, `category_id`, `category_name`, `admin_id`, `admin_name`, `image_name`, `image_description`, `image`, `image_status`, `date_created`) VALUES
(43, 5, 'anime', 5, 'NoniAstara', 'Sylus', 'Sylus adalah salah satu karakter dalam game Love and Deepspace. Sylus pertama kali muncul di episode pertama, Ambiguous Chaos, dari Long-Awaited Revelry.', 'foto1737357699.jpeg', 1, '2025-01-20 07:21:39'),
(45, 2, 'olahraga', 5, 'NoniAstara', 'Olahraga Diet', ' Diet pada dasarnya adalah pola makan, yang cara dan jenis makanannya diatur. Tujuannya adalah untuk menjaga kesehatan tubuh secara keseluruhan. Selain itu, diet juga bertujuan untuk mencapai atau menjaga berat badan yang terkontrol.', 'foto1737357868.jpg', 1, '2025-01-20 07:24:28'),
(46, 4, 'view', 5, 'NoniAstara', 'Pemandangan', '<p>Pemandangan alam adalah keindahan alam yang dapat dipersepsikan melalui komponen mata dalam pancaindra manusia.</p>\r\n', 'foto1737445251.jpg', 1, '2025-01-21 07:41:24'),
(47, 1, 'seni rupa', 5, 'NoniAstara', 'Lukisan Abstrak', '<p>Lukisan merupakan cabang seni rupa dua dimensi yang dibuat dengan media cat atau pigmen di atas permukaan datar seperti kanvas, kertas, atau kayu. Lukisan merupakan ekspresi imajinasi seniman yang dituangkan dalam bentuk gambar.</p>\r\n', 'foto1737358040.jpeg', 1, '2025-01-21 07:41:08'),
(49, 5, 'anime', 9, 'Stefani', 'sasuke uchiha', 'Sasuke Uchiha adalah seorang karakter fiktif dari komik dan anime Naruto. Nama depan Sasuke, konon berasal dari nama seorang ninja legendaris, Sarutobi Sasuke. Sedangkan nama belakangnya, "Uchiha" dibaca sebagai "uchiwa", atau "kipas kertas".', 'foto1737445644.jpeg', 1, '2025-01-21 07:47:24'),
(50, 5, 'anime', 10, 'Eka Purwati', 'boboiboy', 'BoBoiBoy adalah sebuah seri animasi Malaysia yang diproduksi oleh Animonsta Studios. Seri animasi ini menceritakan tentang seorang anak yang memiliki kekuatan luar biasa untuk melawan makhluk asing yang ingin menyerang Bumi.', 'foto1737524684.jpg', 1, '2025-01-22 05:44:44'),
(52, 4, 'view', 6, 'Al', 'Pemandangan ungu', 'gambar pemandangan yang berwarna ungu, saat melihatnya  dapat membuat  menenangkan hati yang lagi emosi.', 'foto1738134562.jpeg', 1, '2025-01-29 07:09:22'),
(53, 5, 'anime', 11, 'Devi Safira', 'Michael Kaiser', 'orang yang sangat cool dan tamvan di anime blok blue', 'foto1738137494.jpeg', 1, '2025-01-29 07:58:14'),
(54, 4, 'anime', 11, 'Devi Safira', 'boboiboy', '<p>anime yang bagus untuk di tonton, apalagi saat mau makan</p>\r\n', 'foto1738139502.jpg', 1, '2025-01-29 08:31:42');

-- --------------------------------------------------------

--
-- Table structure for table `tb_likes`
--

CREATE TABLE IF NOT EXISTS `tb_likes` (
  `like_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_liked` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_likes`
--

INSERT INTO `tb_likes` (`like_id`, `image_id`, `user_id`, `date_liked`) VALUES
(2, 46, 5, '0000-00-00 00:00:00'),
(11, 47, 6, '0000-00-00 00:00:00'),
(12, 45, 6, '0000-00-00 00:00:00'),
(13, 46, 6, '0000-00-00 00:00:00'),
(14, 43, 6, '0000-00-00 00:00:00'),
(15, 44, 6, '0000-00-00 00:00:00'),
(16, 45, 5, '0000-00-00 00:00:00'),
(19, 46, 7, '0000-00-00 00:00:00'),
(20, 45, 7, '0000-00-00 00:00:00'),
(21, 47, 5, '0000-00-00 00:00:00'),
(23, 48, 5, '0000-00-00 00:00:00'),
(24, 50, 10, '0000-00-00 00:00:00'),
(26, 49, 5, '0000-00-00 00:00:00'),
(27, 51, 5, '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tb_category`
--
ALTER TABLE `tb_category`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `tb_comments`
--
ALTER TABLE `tb_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `tb_image`
--
ALTER TABLE `tb_image`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `tb_likes`
--
ALTER TABLE `tb_likes`
  ADD PRIMARY KEY (`like_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_category`
--
ALTER TABLE `tb_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tb_comments`
--
ALTER TABLE `tb_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tb_image`
--
ALTER TABLE `tb_image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `tb_likes`
--
ALTER TABLE `tb_likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_image`
--
ALTER TABLE `tb_image`
  ADD CONSTRAINT `tb_image_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `tb_admin` (`admin_id`),
  ADD CONSTRAINT `tb_image_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `tb_category` (`category_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
