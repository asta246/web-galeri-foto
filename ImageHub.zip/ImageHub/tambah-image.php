<?php
session_start();
include 'db.php';
if($_SESSION['status_login'] != true){
    echo '<script>window.location="login.php"</script>';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IMAGEHUB</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f7fc;
        margin: 0;
        padding: 0;
    }

    header {
        background-color: rgb(123, 26, 188);
        color: white;
        padding: 20px 0;
        text-align: center;
    }

    header h1 {
        margin: 0;
        font-size: 30px;
    }

    header ul {
        list-style: none;
        padding: 0;
        margin: 10px 0;
    }

    header ul li {
        display: inline;
        margin: 0 15px;
    }

    header ul li a {
        color: #fff;
        text-decoration: none;
    }

    header ul li a:hover {
        text-decoration: underline;
    }

    .container {
        width: 80%;
        max-width: 1200px;
        margin: 0 auto;
    }

    .section {
        margin-top: 40px;
    }

    .box {
        background-color: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgb(123, 26, 188);
        margin-bottom: 40px;
    }

    h3 {
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
    }

    input[type="text"], input[type="file"], input[type="submit"], select, textarea {
        width: 100%;
        padding: 12px;
        margin: 10px 0;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-sizing: border-box;
    }

    textarea {
        height: 150px;
    }

    input[type="submit"] {
        background-color: rgb(123, 26, 188);
        color: white;
        padding: 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: rgb(76, 8, 97);
    }

    footer {
        background-color: rgb(123, 26, 188);
        color: white;
        text-align: center;
        padding: 10px;
        position: fixed;
        bottom: 0;
        width: 100%;
    }

    footer small {
        font-size: 12px;
    }

    @media (max-width: 768px) {
        .container {
            width: 90%;
        }
    }
</style>
</head>

<body>
    <!-- header -->
    <header>
        <div class="container">
        <h1><a href="dashboard.php">IMAGEHUB</a></h1>
        <ul>
           <li><a href="dashboard.php">Dashboard</a></li>
           <li><a href="profil.php">Profil</a></li>
           <li><a href="data-image.php">Data Foto</a></li>
           <li><a href="Keluar.php">Keluar</a></li>
        </ul>
        </div>
    </header>
    
    <!-- content -->
    <div class="section">
        <div class="container">
            <h3>Tambah Data Foto</h3>
            <div class="box">
             
               <form action="" method="POST" enctype="multipart/form-data">
                
                   <?php   
                   $result = mysqli_query($conn,"select * from tb_category");   
                   $jsArray = "var prdName = new Array();\n";   
                   echo '<select class="input-control" name="kategori" onchange="document.getElementById(\'prd_name\').value = prdName[this.value]" required>  
                         <option>-Pilih Kategori Foto-</option>'; 
                   while ($row = mysqli_fetch_array($result)) {  
                       echo ' <option value="' . $row['category_id'] . '">' . $row['category_name'] . '</option>';  
                       $jsArray .= "prdName['" . $row['category_id'] . "'] = '" . addslashes($row['category_name']) . "';\n"; 
                   }
                   echo '</select>';
                   ?>
                   </select>
                   <input type="hidden" name="nama_kategori" id="prd_name">
                   <input type="hidden" name="adminid" value="<?php echo $_SESSION['a_global']->admin_id ?>">
                   <input type="text" name="namaadmin" class="input-control" value="<?php echo $_SESSION['a_global']->admin_name ?>" readonly="readonly">
                   <input type="text" name="nama" class="input-control" placeholder="Nama Foto" required>
                   <textarea class="input-control" name="deskripsi" placeholder="Deskripsi"></textarea><br />
                   <input type="file" name="gambar" class="input-control" required>
                   <select class="input-control" name="status">
                       <option value="">--Pilih--</option>
                       <option value="1">Aktif</option>
                       <option value="0">Tidak Aktif</option> 
                   </select>
                   <input type="submit" name="submit" value="Submit" class="btn">
               </form>
               <?php
               if(isset($_POST['submit'])){
                   // menampung inputan dari form
                   $kategori  = $_POST['kategori'];
                   $nama_ka   = $_POST['nama_kategori'];
                   $ida   = $_POST['adminid'];
                   $user = $_POST['namaadmin'];
                   $nama = $_POST['nama'];
                   $deskripsi = $_POST['deskripsi'];
                   $status = $_POST['status'];
                   
                   // menampung data file yang diupload
                   $filename = $_FILES['gambar']['name'];
                   $tmp_name = $_FILES['gambar']['tmp_name'];
                   
                   // Mendapatkan ekstensi file
                   $type1 = explode('.', $filename);
                   $type2 = strtolower($type1[1]);

                   $newname = 'foto'.time().'.'.$type2; 

                   // menampung data format file yang diizinkan
                   $tipe_diizinkan = array('jpg', 'jpeg', 'png', 'gif');
                   
                   // jika format file valid, lanjutkan proses upload
                   if(in_array($type2, $tipe_diizinkan)){
                       // proses upload file
                       move_uploaded_file($tmp_name, './foto/'.$newname);
                       
                       // memasukkan data ke database
                       $insert = mysqli_query($conn, "INSERT INTO tb_image VALUES (
                                   null,
                                   '".$kategori."',
                                   '".$nama_ka."',
                                   '".$ida."',
                                   '".$user."',
                                   '".$nama."',
                                   '".$deskripsi."',
                                   '".$newname."',
                                   '".$status."',
                                   null
                               )");
                       
                       if($insert){
                           echo '<script>alert("Tambah Foto berhasil")</script>';
                           echo '<script>window.location="data-image.php"</script>';
                       }else{
                           echo 'gagal'.mysqli_error($conn);
                       }
                   } else {
                       // Jika file tidak valid, tampilkan pesan kesalahan secara halus
                       echo '<script>alert("Format file tidak diizinkan. Silakan upload file dengan format jpg, jpeg, png, atau gif.")</script>';
                   }
               }
               ?>
        </div>
        </div>
    </div>
    
    <!-- footer -->
    <footer>
        <div class="container">
            <small>Asta &copy; 2025 - ImageHub.</small>
        </div>
    </footer>
    <script>
            CKEDITOR.replace( 'deskripsi' );
    </script>
    <script type="text/javascript"><?php echo $jsArray; ?></script>
</body>
</html>
